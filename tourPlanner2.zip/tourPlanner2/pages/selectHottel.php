<?php
$hottelId = '';
if (isset($_POST['hottelId'])) {
    $hottelId = $_POST['hottelId'];
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

    <link rel="stylesheet" href="../CSS/pages.css">
</head>

<body>
    <section class="container-xxl py-5" id="fullHottelContainer">
        <div class="text-center">
            <!-- <h6 class="section-title bg-white text-center text-primary px-3">Blogs</h6> -->
            <h2 class="mb-5">These rooms are available wight now</h2>
            <h3 class="mv-5">Please select your room</h3>
        </div>

        <div class="row row-cols-1 row-cols-md-3 g-4" id="hottelCards">

            <form class="col" method="POST" action="confirmHottel.php">
                <div class="card h-100">
                    <?php $imgAdd = 'admin/' . $post['image']; ?>
                    <img src="../img/hottel.jpeg" class="card-img-top postImage" alt="...">
                    <button class="hBookingCardBtn">
                        <div class="card-body">
                            <h5 class="card-title">Hello<?php echo $post['title']; ?></h5>
                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Vero consequatur, natus ipsam asperiores placeat fugit eius obcaecati. Incidunt, molestiae non!</p>

                            <p class="bookNow">Book Now</p>
                            <input type="text" value="Here is room id" class="hidden">
                        </div>
                    </button>
                </div>
            </form>


        </div>

    </section>
</body>

</html>