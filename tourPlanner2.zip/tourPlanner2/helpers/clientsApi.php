<?php

function fetchPost(){
    $pdo = require_once "dbConnector.php";
    $statement = $pdo->prepare("SELECT title, description, image FROM postInfo ORDER BY id DESC;");
    $statement->execute();
    return $statement->fetchAll(PDO::FETCH_ASSOC);
}